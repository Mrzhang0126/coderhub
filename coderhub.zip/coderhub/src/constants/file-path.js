const AVATAR_PATH = './uploads/avatar';
const PICTURE_PATH = './uploads/picture';

module.exports = {
  AVATAR_PATH,
  PICTURE_PATH
}
